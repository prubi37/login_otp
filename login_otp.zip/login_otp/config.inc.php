<?php

$rcmail_config['clickatell_api_key'] = 'enter-your-api-here';
$rcmail_config['clickatell_sender_id'] = '';
